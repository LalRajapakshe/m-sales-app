enum UserType {
  GUEST,
  MEMBER,
}
